# 项目改动说明：旧 run 与 18 个 perf 场景

本目录对应旧 run `02db55c61f0d14bb`。其中 `perf/` 是本项目在远端服务器上完成的 18 个性能场景结果，来源于 3 个 KV 配置和 6 个输入输出组合。本文记录产生这些结果时实际采用的项目适配和配置，避免把本次后续的 `max_tokens=96` 质量测试与旧 perf 结果混在一起。

## 1. 相对原始手册和仓库的项目适配

- 后端明确改为项目专用的本地 vLLM（`local_vllm`），不使用远端 API，也不直接复用其他项目的运行环境。
- 在 `/mnt_d/autokv-skip/.venv-vllm-pgcg` 中建立项目专用 vLLM 环境；该环境基于 `/mnt_d/pg-cg-lite-work-huangxiaoyuan` 中可用环境的依赖重新准备。运行时使用该环境的 `vllm` 命令。
- 模型使用本地 Hugging Face snapshot：`mistralai/Mistral-7B-Instruct-v0.3`，revision 为 `c170c708c41dac9275d15a8fff4eca08d52bab71`，避免测试期间访问外网。
- 将宿主机硬件锁定从手册原先的驱动 `535.230.02` 适配为服务器实际驱动 `580.173.02`。配置中的 GPU、显存和架构仍锁定为 `NVIDIA RTX A6000`、`49140 MiB`、compute capability `8.6`。
- 保持无管理员权限运行，不修改系统驱动、内核、Docker 或 CUDA toolkit；项目文件、模型缓存和虚拟环境均放在 `/mnt_d/autokv-skip`。
- vLLM benchmark 命令改为调用本地服务的正确模型标识 `mistralai/Mistral-7B-Instruct-v0.3`，并使用本地 tokenizer snapshot。benchmark 失败门禁同时要求结果文件、容量证据、指标和矩阵状态完整，缺失时停止并保留证据，不接受部分结果作为成功。
- 项目增加了本地 vLLM 的服务生命周期、环境探测、模型 revision/runtime 记录、可恢复矩阵状态和结果完整性校验。每个结果均记录 `runtime_id`、模型 revision、服务命令和 telemetry 日志。

## 2. 该 run 固定的运行环境

- backend：`local_vllm`
- vLLM runtime ID：`local-vllm-93d4d2e3ba80c7be`
- vLLM：`0.1.dev19475+gc18d29d36`
- PyTorch：`2.13.0+cu129`
- CUDA runtime：`12.9`
- FlashInfer：`0.6.16.post3`
- 服务参数：`bfloat16` model dtype、FlashInfer attention、`max-model-len=32768`、KV cache budget `16G`、seed `42`、tensor parallel size `1`。
- FP8 KV 配置使用 `fp8_e4m3`、`--calculate-kv-scales`；BF16 基线使用 `bfloat16` KV。

## 3. 18 个 perf 场景的具体矩阵

`perf/index.json` 标记为 `complete: true`，包含以下矩阵：

- 配置：`bf16`、`fp8`、`auto-4`。
- 每个配置 6 个场景：输入长度 `1024`、`8192`、`16384` 分别配合输出长度 `32`、`256`。
- 每个场景 20 个 prompts，1 个 warmup，无限请求速率，temperature `0`，忽略 EOS，并记录 TTFT、TPOT、ITL、E2E 的 P90/P99 指标。
- `bf16`：所有层使用 BF16 KV。
- `fp8`：所有层使用 FP8 KV，不跳过层。
- `auto-4`：FP8 KV，并将第 `20`、`23`、`24`、`27` 层保留为 BF16 KV。

## 4. 与本次质量 run 的关系

- 旧 run 的 quick profile 使用质量请求 `max_tokens=64`；这是旧结果生成时的 profile 状态。perf 命令本身使用固定的随机输出长度 `32` 和 `256`，不由质量请求的 `max_tokens` 控制。
- 旧 run 的 dataset hash 为 `750535abe0680a56d0cc99a1d2cf4ae5ebb7262e88a36056ee69bdabcc53457d`，profile hash 为 `658778c210c802e0e21100d9cfd41b0847807b849d4adf65fab67bba6fbe93ea`。
- 当前质量 run `1cf1ec252f4e7e62` 重新生成了数据清单并将质量上限改为 `96`；它没有覆盖、修改或混入本目录的 18 个 perf 结果。

## 5. 可核对的来源

- [perf 索引](perf/index.json)
- [旧 run 清单](run-manifest.json)
- [层选择结果](selection.json)
- `perf/*.command.json`：实际服务和 benchmark 命令
- `perf/*.summary.json`：每个配置的 6 个场景汇总
- `perf/*/in*-out*-rep0.json`：18 个场景的原始 vLLM 结果

该 run 的 source commit 为 `6f8ceec7daa38fb769d301fc28611e537a8c4528`，工作树带有已记录的未提交项目适配改动；run manifest 中的 `tree_sha256` 为 `6b21daf9cb745fb1ceba71efa12168b1e69cba36a4d8214ce87ad784aece96b0`。
