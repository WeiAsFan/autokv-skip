# 项目改动说明：本次 max_tokens=96 质量 run

本目录对应本次质量测试 run `1cf1ec252f4e7e62`。本文记录产生这些结果时实际采用的项目改动，并说明它与旧的 18 个 perf 场景 run `02db55c61f0d14bb` 的差异。

## 1. 延续的项目适配

- 后端明确使用项目专用的本地 vLLM（`local_vllm`），不使用远端 API，也不直接复用其他目录的 vLLM 环境。
- 运行环境为 `/mnt_d/autokv-skip/.venv-vllm-pgcg`，其依赖基于 `/mnt_d/pg-cg-lite-work-huangxiaoyuan` 中的可用 vLLM 环境重新准备。
- 模型使用本地 snapshot `mistralai/Mistral-7B-Instruct-v0.3`，固定 revision `c170c708c41dac9275d15a8fff4eca08d52bab71`，测试过程不依赖外网。
- 宿主机硬件锁定为服务器实际环境：驱动 `580.173.02`、GPU `NVIDIA RTX A6000`、显存 `49140 MiB`、compute capability `8.6`。项目不要求管理员权限，也没有修改系统驱动、内核或 CUDA toolkit。
- `autokv/commands.py`、`autokv/benchmark.py`、`autokv/doctor.py`、`autokv/experiment.py`、`autokv/local_runtime.py` 等共同实现本地 vLLM 服务管理、正确的模型标识和 tokenizer 路径、runtime/model revision 记录、矩阵断点恢复以及失败门禁。
- benchmark 失败门禁要求每个配置的结果文件、指标、容量证据和矩阵状态完整；出现服务失败、结果缺失或完整性不一致时，测试应停止而不是生成部分成功结果。

## 2. 本次相对旧 run 的实际改动

本次只针对质量生成上限做了重新实验，未重跑 perf。run manifest 的 source hash 对比表明，旧 run 与本次 run 之间实际变化集中在以下配置文件：

- `configs/quick.json`：`quality.max_tokens` 从 `64` 改为 `96`，并继续使用驱动 `580.173.02`。
- `configs/full.json`：`quality.max_tokens` 从 `64` 改为 `96`，并继续使用驱动 `580.173.02`。
- `autokv/config.py`：默认 profile 的 `max_tokens` 从 `64` 改为 `96`；默认期望驱动保持为 `580.173.02`。
- 质量设计文档同步将质量请求和 token 余量说明更新为 `max_tokens=96`。
- 因 profile hash 改变，本次重新生成了独立的数据清单，未复用旧 run 的质量结果。

除上述 profile 上限和说明文档外，两个 run 的核心运行代码、模型 revision、vLLM runtime、层选择和服务参数保持一致。两次 run 的 source commit 都是 `6f8ceec7daa38fb769d301fc28611e537a8c4528`，但由于配置改动，source tree hash 和 profile hash 不同。

## 3. 本次固定运行环境和配置

- backend：`local_vllm`
- vLLM runtime ID：`local-vllm-93d4d2e3ba80c7be`
- vLLM：`0.1.dev19475+gc18d29d36`
- PyTorch：`2.13.0+cu129`
- CUDA runtime：`12.9`
- FlashInfer：`0.6.16.post3`
- 模型 dtype：`bfloat16`
- attention backend：FlashInfer
- `max-model-len=32768`、KV cache budget `16G`、seed `42`、tensor parallel size `1`
- FP8 KV 使用 `fp8_e4m3` 和 `--calculate-kv-scales`；BF16 基线使用 BF16 KV。
- 自动选择的层：`20`、`23`、`24`、`27`；对应的 inverted 选择为 `21`、`22`、`25`、`26`。

## 4. 本次质量结果范围

- 11 个配置：`bf16`、`fp8`、`auto-4`、`random-4-1` 至 `random-4-5`、`first-4`、`last-4`、`inverted-4`。
- 每个配置 18 条样本，共 198 条记录。
- 质量模式：`nll`。
- 质量请求上限：`max_tokens=96`。
- `quality/index.json` 标记为 `complete: true`。
- 本次 dataset hash：`63b7d9fc2be0de81d926cb67b1260b401e4f6aa9adabcf602f5d4f9d8d9c7615`。
- 本次 profile hash：`5c424bfe5edfb33d6aabf196d37b2245de4a37d0c2f0bd5fcec819d8ef36446e`。

本次质量测试实际有 168/198 条样本生成到 96-token 上限；BF16 基线输出长度为 57 至 67 tokens。Exact Match 为 `18/198`，全部来自 BF16 基线。量化配置仍为 0 Exact Match，因此将上限从 64 提高到 96 后，量化配置的失败不能再简单归因于旧的 64-token 截断。

## 5. 与旧 perf 结果的边界

- 旧的 18 个 perf 场景位于本机 `../02db55c61f0d14bb/perf/`，对应独立 run `02db55c61f0d14bb`。
- 本次质量 run 没有修改旧 perf 文件，也没有将旧 run 的文件复制到本目录。
- perf 的随机输出长度由 benchmark 矩阵的 `32`/`256` 参数决定，不由本次质量请求的 `max_tokens=96` 决定。

## 6. 可核对的来源

- [质量索引](quality/index.json)
- [本次 run 清单](run-manifest.json)
- [层选择结果](selection.json)
- `quality/*.command.json`：每个配置的实际服务命令
- `quality/*.jsonl`：198 条质量样本记录
- `quality/*.server.log`：服务端日志

本次 run 的 source tree hash 为 `408eece5425b984b8531f8ea9d028143344741d14f2ac5d809936370667efdf4`。项目测试在本次改动后为 `94 passed, 2 skipped, 4 subtests passed`。
