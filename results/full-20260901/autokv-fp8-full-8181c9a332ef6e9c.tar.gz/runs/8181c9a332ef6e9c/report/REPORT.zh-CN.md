# AutoKV-Skip 实验报告

生成时间（UTC）：2026-09-01T06:08:25.085442+00:00

## 结论摘要

- Auto-4 保留的 BF16 KV 层：1, 4, 8, 12。
- FP8 实测 KV token capacity / BF16：2.000×。
- Auto-4 实测 KV token capacity / BF16：1.778×；理论值 1.778×。
- Auto-4 相对全 FP8 的配对 Q 差：0.0000，95% CI [-0.0001, 0.0001]。
- Gap recovery：BF16 与 FP8 的 Q 缺口不超过 0.01，本任务未观察到足够缺口，因此不计算恢复率。
- A6000 不具备原生 FP8 Tensor Core；本项目的主结论是 KV 容量/带宽与质量折中，不预设延迟必然下降。

## 不可变环境

- GPU：NVIDIA RTX A6000
- 驱动：580.173.02（项目不更新驱动）
- 运行后端：`local_vllm`
- 运行环境：`/mnt_d/huangxiaoyuan/autokv-skip/.venv-vllm-pgcg`
- 运行身份：`local-vllm-93d4d2e3ba80c7be`
- 模型 revision：`c170c708c41dac9275d15a8fff4eca08d52bab71`
- vLLM：0.1.dev19475+gc18d29d36；CUDA：12.9
- 源码树 SHA-256：`64ad8dcaf4f36cf9f3b9575a0a324b656d3ed06f314907226ca9709154542c70`
- Git commit：`2c6a4e1ac96e9835a6af2ad450cb9dfa269e4953`；dirty：False
- 注意力后端：FLASHINFER；KV 预算：16G；动态 token scales：关闭（C 配置已验证）。
- 全实验质量评分模式：nll。
- 选层搜索范围：all-32-layers。

## KV 显存公式

- BF16：131,072 bytes/token。
- FP8：65,536 bytes/token。
- Auto-4：73,728 bytes/token。

## 分组与逐层敏感性

分数均为相对全 FP8 的 Q 增量；`✓` 表示最终 Auto-4 选中层。

| 类型 | 候选 | ΔQ | 选中 |
|---|---|---:|---|
| 单层 | 0 | -0.000330 |  |
| 单层 | 1 | 0.000110 | ✓ |
| 单层 | 2 | 0.000045 |  |
| 单层 | 3 | -0.000056 |  |
| 单层 | 4 | 0.000070 | ✓ |
| 单层 | 5 | -0.000012 |  |
| 单层 | 6 | -0.000060 |  |
| 单层 | 7 | -0.000027 |  |
| 单层 | 8 | 0.000095 | ✓ |
| 单层 | 9 | -0.000152 |  |
| 单层 | 10 | -0.000092 |  |
| 单层 | 11 | -0.000082 |  |
| 单层 | 12 | 0.000067 | ✓ |
| 单层 | 13 | -0.000032 |  |
| 单层 | 14 | -0.000025 |  |
| 单层 | 15 | 0.000051 |  |
| 单层 | 16 | 0.000022 |  |
| 单层 | 17 | 0.000053 |  |
| 单层 | 18 | 0.000058 |  |
| 单层 | 19 | 0.000037 |  |
| 单层 | 20 | -0.000008 |  |
| 单层 | 21 | -0.000069 |  |
| 单层 | 22 | -0.000052 |  |
| 单层 | 23 | 0.000012 |  |
| 单层 | 24 | 0.000010 |  |
| 单层 | 25 | -0.000028 |  |
| 单层 | 26 | 0.000021 |  |
| 单层 | 27 | 0.000025 |  |
| 单层 | 28 | -0.000030 |  |
| 单层 | 29 | 0.000003 |  |
| 单层 | 30 | -0.000004 |  |
| 单层 | 31 | -0.000033 |  |

## 质量结果

| 配置 | 样本数 | EM | Q | Answer NLL |
|---|---:|---:|---:|---:|
| bf16 | 45 | 1.0000 | 0.9952 | 0.0245 |
| fp8 | 45 | 1.0000 | 0.9951 | 0.0247 |
| auto-4 | 45 | 1.0000 | 0.9952 | 0.0245 |
| first-4 | 45 | 1.0000 | 0.9951 | 0.0250 |
| inverted-4 | 45 | 1.0000 | 0.9948 | 0.0263 |
| last-4 | 45 | 1.0000 | 0.9952 | 0.0245 |
| random-4-1 | 45 | 1.0000 | 0.9951 | 0.0249 |
| random-4-2 | 45 | 1.0000 | 0.9951 | 0.0248 |
| random-4-3 | 45 | 1.0000 | 0.9952 | 0.0244 |
| random-4-4 | 45 | 1.0000 | 0.9952 | 0.0245 |
| random-4-5 | 45 | 1.0000 | 0.9948 | 0.0262 |

### 配对区间

- BF16 − FP8：0.0000，95% CI [-0.0001, 0.0002]。
- Auto-4 − FP8：0.0000，95% CI [-0.0001, 0.0001]。

## KV 容量

| 配置 | KV tokens | 相对 BF16 | 最大并发 |
|---|---:|---:|---:|
| bf16 | 131,072 | 1.000× | 4.00 |
| fp8 | 262,144 | 2.000× | 8.00 |
| auto-4 | 232,992 | 1.778× | 7.11 |

### 理论容量与运行时证据

16 GiB 预算按 KV 元素字节数计算理论 token 数；偏差超过 10% 时，只有可重算 tokens 的可用 KV 内存，或足以覆盖偏差的 padding 浪费上界，才算定量解释。普通 block/page 文本不能让门禁通过。

| 配置 | 理论 tokens | 实测 tokens | 相对偏差 | ≤10% | 定量解释 |
|---|---:|---:|---:|---|---|
| bf16 | 131072 | 131072 | 0.00% | 是 | 0 条（充分） |
| fp8 | 262144 | 262144 | 0.00% | 是 | 0 条（充分） |
| auto-4 | 233016 | 232992 | 0.01% | 是 | 0 条（充分） |

#### 容量证据定位

- bf16：server log `runs/8181c9a332ef6e9c/perf/bf16-cc8cf39b4c7d.server.log`；SHA-256 `92a9207f690e02b490071073c319c5e476ce4010a954b615dcd1e78cca01aa16`。
  - 摘录：`(APIServer pid=1413030) INFO 09-01 12:33:02 [entrypoints/.../utils/api_utils.py:273] non-default args: {'model_tag': '/mnt_d/huangxiaoyuan/autokv-skip/.cache/huggingface/models--mistralai--Mistral-7B-Instruct-v0.3/snapshots/c170c708c41dac92`
  - 摘录：`(EngineCore pid=1413198) INFO 09-01 12:33:21 [v1/worker/gpu_worker.py:491] Initial free memory 47.12 GiB, reserved 16.0 GiB memory for KV Cache as specified by kv_cache_memory_bytes config and skipped memory profiling. This does not respect`
  - 摘录：`(EngineCore pid=1413198) INFO 09-01 12:33:21 [v1/core/kv_cache_utils.py:2235] GPU KV cache size: 131,072 tokens`
- fp8：server log `runs/8181c9a332ef6e9c/perf/fp8-5e7d6b463fa6.server.log`；SHA-256 `075cfd02f2d9b06124ce6e51b3e96af4e19860c9daf10ec15c4532d495d6b774`。
  - 摘录：`(APIServer pid=1422174) INFO 09-01 13:06:03 [entrypoints/.../utils/api_utils.py:273] non-default args: {'model_tag': '/mnt_d/huangxiaoyuan/autokv-skip/.cache/huggingface/models--mistralai--Mistral-7B-Instruct-v0.3/snapshots/c170c708c41dac92`
  - 摘录：`(EngineCore pid=1422387) INFO 09-01 13:06:26 [v1/worker/gpu_worker.py:491] Initial free memory 47.12 GiB, reserved 16.0 GiB memory for KV Cache as specified by kv_cache_memory_bytes config and skipped memory profiling. This does not respect`
  - 摘录：`(EngineCore pid=1422387) INFO 09-01 13:06:26 [v1/core/kv_cache_utils.py:2235] GPU KV cache size: 262,144 tokens`
- auto-4：server log `runs/8181c9a332ef6e9c/perf/auto-4-d5cefa386053.server.log`；SHA-256 `c1af6b6fc8cd75cfc81fcc2c0f11c4ee3c46d46482e808c0071e986378c1262e`。
  - 摘录：`(APIServer pid=1430926) INFO 09-01 13:36:08 [entrypoints/.../utils/api_utils.py:273] non-default args: {'model_tag': '/mnt_d/huangxiaoyuan/autokv-skip/.cache/huggingface/models--mistralai--Mistral-7B-Instruct-v0.3/snapshots/c170c708c41dac92`
  - 摘录：`(EngineCore pid=1431099) INFO 09-01 13:36:29 [platforms/interface.py:749] Setting attention block size to 32 tokens so the quantized primary KV page covers the higher-precision padded-spec page.`
  - 摘录：`(EngineCore pid=1431099) INFO 09-01 13:36:31 [v1/worker/gpu_worker.py:491] Initial free memory 47.12 GiB, reserved 16.0 GiB memory for KV Cache as specified by kv_cache_memory_bytes config and skipped memory profiling. This does not respect`

### 遥测与矩阵状态

| 配置 | dmon 路径 | dmon SHA-256 | matrix state 路径 | matrix SHA-256 |
|---|---|---|---|---|
| bf16 | runs/8181c9a332ef6e9c/perf/bf16-cc8cf39b4c7d.dmon.log | 3f658c6741d679a2c013740d0661b0f0ba1bb7819bfed772b6d82cb7f065b64a | runs/8181c9a332ef6e9c/perf/bf16-cc8cf39b4c7d.matrix.state.json | 18af9e2a3682be14b0d6a707a37feac7375c925c48333dc5fe1ddd6e1910fd6d |
| fp8 | runs/8181c9a332ef6e9c/perf/fp8-5e7d6b463fa6.dmon.log | 8be0207193bc9aa3b776aec4dc55be2b94eae5775cc35e4b386cb1ab262adaf3 | runs/8181c9a332ef6e9c/perf/fp8-5e7d6b463fa6.matrix.state.json | 264487ecea1c49d872ebf15dd5cfab9192eb2389043a40f0ecd678f9b1626181 |
| auto-4 | runs/8181c9a332ef6e9c/perf/auto-4-d5cefa386053.dmon.log | 8deb3b26d9e1adb3600058fc83e9235cbba1e185d5e59879a666e1feb4feed34 | runs/8181c9a332ef6e9c/perf/auto-4-d5cefa386053.matrix.state.json | 3da4cca2f858578b4f2b2cab9e984b5b82b70f60c35e045241c0de02fd400348 |

## 服务性能

跨长度只保留描述性均值；正式比较一律在相同 input/output 场景内进行。逐场景原始 JSON 与 `nvidia-smi dmon` 日志保存在 `perf/`。

### 逐场景性能

| 配置 | Input | Output | 重复 | Req/s | Output tok/s | Median TTFT | P99 TTFT | Median TPOT | P99 TPOT | Median ITL | P99 ITL |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| bf16 | 1024 | 32 | 3 | 6.753 | 216.085 | 3767.057 | 6462.929 | 108.777 | 206.229 | 33.769 | 284.577 |
| bf16 | 1024 | 256 | 3 | 5.314 | 1360.373 | 361.443 | 417.939 | 35.284 | 35.465 | 35.331 | 39.982 |
| bf16 | 8192 | 32 | 3 | 0.792 | 25.337 | 30556.349 | 61627.872 | 322.206 | 324.702 | 322.753 | 357.958 |
| bf16 | 8192 | 256 | 3 | 0.493 | 126.217 | 42071.888 | 92871.444 | 106.164 | 109.476 | 46.781 | 358.987 |
| bf16 | 16384 | 32 | 3 | 0.344 | 11.003 | 72503.891 | 143055.856 | 367.066 | 368.669 | 366.441 | 441.710 |
| bf16 | 16384 | 256 | 3 | 0.228 | 58.494 | 101585.974 | 206023.179 | 104.034 | 106.407 | 44.565 | 442.120 |
| fp8 | 1024 | 32 | 3 | 7.680 | 245.757 | 3772.209 | 5730.605 | 84.936 | 184.656 | 30.092 | 279.520 |
| fp8 | 1024 | 256 | 3 | 6.113 | 1564.844 | 370.239 | 402.931 | 30.444 | 30.733 | 30.505 | 35.565 |
| fp8 | 8192 | 32 | 3 | 0.830 | 26.570 | 28352.669 | 58798.562 | 324.127 | 328.338 | 324.864 | 362.280 |
| fp8 | 8192 | 256 | 3 | 0.606 | 155.174 | 32638.262 | 72160.563 | 161.214 | 183.682 | 48.059 | 372.006 |
| fp8 | 16384 | 32 | 3 | 0.341 | 10.903 | 73251.871 | 144475.747 | 370.566 | 372.932 | 370.372 | 451.619 |
| fp8 | 16384 | 256 | 3 | 0.277 | 71.012 | 82305.889 | 170528.359 | 190.009 | 196.912 | 49.049 | 462.096 |
| auto-4 | 1024 | 32 | 3 | 7.379 | 236.130 | 3781.983 | 5948.120 | 91.550 | 190.665 | 30.907 | 280.912 |
| auto-4 | 1024 | 256 | 3 | 5.879 | 1505.035 | 434.314 | 505.343 | 31.490 | 31.990 | 31.441 | 35.554 |
| auto-4 | 8192 | 32 | 3 | 0.820 | 26.250 | 28550.786 | 59492.597 | 323.301 | 328.387 | 324.619 | 357.379 |
| auto-4 | 8192 | 256 | 3 | 0.587 | 150.152 | 32692.550 | 73712.036 | 163.924 | 168.373 | 49.291 | 373.135 |
| auto-4 | 16384 | 32 | 3 | 0.341 | 10.908 | 73135.077 | 144393.534 | 370.243 | 372.502 | 371.244 | 449.775 |
| auto-4 | 16384 | 256 | 3 | 0.273 | 69.963 | 82818.106 | 172184.378 | 177.064 | 186.403 | 49.526 | 460.759 |

## 预注册验收

| 条件 | 结果 |
|---|---|
| FP8 capacity ≥ 1.85× BF16 | 通过 |
| Auto-4 capacity ≥ 1.65× BF16 | 通过 |
| 可测缺口时 recovery ≥ 50% | 通过 |
| Auto-4 Q 高于 Random-4 中位数 | 通过 |
| Auto-4 Q 高于 Inverted-4 | 通过 |
| 容量偏差或定量运行时解释完整 | 通过 |

## 局限与诚实表述

- `--calculate-kv-scales` 只从固定 seed 的 warmup random tokens 估计一次 scales，不代表数据集标定的最佳 FP8 上限。
- quick profile 的 coarse-to-fine 搜索可能漏掉分散在低分组中的敏感层；full profile 用于检验这一点。
- 单层边际敏感度近似忽略层间非加性交互，联合 Auto-4 的实测结果才是最终依据。
- 如果 Auto-4 不优于随机或反向对照，应报告负结果，而不是更换指标或筛选运行。
- FP8 在 Ampere 上需要存储转换；若 TTFT/ITL 变慢，应作为真实硬件结果报告。
- 质量请求为非流式，质量 JSONL 的 `ttft_ms` 明确为 null；TTFT 只引用 `vllm bench serve` 性能产物。
