"""Build metadata for flashinfer package."""
__version__ = "0.6.18"
__git_commit__ = "a4c17d77a15fbff1ef7b34a4ad2b5faaa5bdd6dc"
