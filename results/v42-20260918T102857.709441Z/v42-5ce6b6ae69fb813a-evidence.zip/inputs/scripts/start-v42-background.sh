#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
V41_ROOT="${AUTOKV_V41_ROOT:-/mnt_d/huangxiaoyuan/autokv-skip-v4.1}"
V41_RUN="${AUTOKV_V41_RUN:-$V41_ROOT/runs/v41-40ef467cef6a32d2}"
VLLM_BIN="${AUTOKV_VLLM_BIN:-/mnt_d/huangxiaoyuan/autokv-skip/.venv-vllm-pgcg/bin/vllm}"
MODEL_PATH="${AUTOKV_MODEL_PATH:-/mnt_d/huangxiaoyuan/autokv-skip/.cache/huggingface/models--mistralai--Mistral-7B-Instruct-v0.3/snapshots/c170c708c41dac9275d15a8fff4eca08d52bab71}"
FP4_SITE="${AUTOKV_FP4_SITE:-$V41_ROOT/.runtime/v41/site}"

if [[ "${AUTOKV_V42_CHILD:-0}" != "1" ]]; then
    RUNS_DIR="$PROJECT_ROOT/runs"
    mkdir -p "$RUNS_DIR"
    if [[ -n "${AUTOKV_V42_LOG:-}" ]]; then
        LOG_PATH="$AUTOKV_V42_LOG"
    else
        stamp="$(date -u +%Y%m%dT%H%M%SZ)"
        LOG_PATH="$RUNS_DIR/v42-cli-background-$stamp.log"
    fi
    PID_PATH="${AUTOKV_V42_PID:-${LOG_PATH%.log}.pid}"
    EXIT_PATH="${AUTOKV_V42_EXITCODE:-${LOG_PATH%.log}.exitcode}"
    LAUNCH_PATH="${AUTOKV_V42_LAUNCH_LOG:-${LOG_PATH%.log}.launch.log}"
    for path in "$LOG_PATH" "$PID_PATH" "$EXIT_PATH" "$LAUNCH_PATH"; do
        if [[ -e "$path" ]]; then
            echo "目标文件已存在，为避免覆盖旧证据而停止：$path" >&2
            exit 1
        fi
    done
    if ss -ltn | grep -Eq '[:.]8010[[:space:]]'; then
        echo '8010 已被占用，未启动新的实验。' >&2
        exit 1
    fi
    if ! ss -ltn | grep -Eq '[:.]35001[[:space:]]'; then
        echo '未检测到 35001 服务，未启动新的实验。' >&2
        exit 1
    fi
    if [[ ! -x "$VLLM_BIN" || ! -d "$MODEL_PATH" || ! -d "$FP4_SITE" || ! -d "$V41_RUN" ]]; then
        echo 'v4.2 运行所需的 vLLM、模型、FP4 site 或 v4.1 来源运行目录不存在，未启动实验。' >&2
        exit 1
    fi
    export AUTOKV_V42_LOG="$LOG_PATH" AUTOKV_V42_PID="$PID_PATH" AUTOKV_V42_EXITCODE="$EXIT_PATH"
    export AUTOKV_V42_LAUNCH_LOG="$LAUNCH_PATH" AUTOKV_V42_CHILD=1
    export AUTOKV_V41_ROOT="$V41_ROOT" AUTOKV_V41_RUN="$V41_RUN"
    export AUTOKV_VLLM_BIN="$VLLM_BIN" AUTOKV_MODEL_PATH="$MODEL_PATH" AUTOKV_FP4_SITE="$FP4_SITE"
    nohup "$0" >"$LAUNCH_PATH" 2>&1 &
    child_pid=$!
    printf '%s\n' "$child_pid" >"$PID_PATH"
    echo "v4.2 实验已在后台启动；控制器 PID：$child_pid"
    echo "运行日志：$LOG_PATH"
    echo "退出码：$EXIT_PATH（实验结束后生成）"
    exit 0
fi

cd "$PROJECT_ROOT"
set +e
bash scripts/run-v42.sh --reuse-run "$V41_RUN" --json 2>&1 | tee "$AUTOKV_V42_LOG"
status=${PIPESTATUS[0]}
set -e
printf '%s\n' "$status" >"$AUTOKV_V42_EXITCODE"
exit "$status"
